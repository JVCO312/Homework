import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут
        // в поход. Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут
        // в поход даже в плохую погоду. В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится
        // от сдачи тренерского экзамена (isJimFree), или тренер Кейт, если она вернётся из путешествия
        // (hasKateComeBack). Вести детей может только один тренер. Если Джим и Кейт смогут вести детей вместе,
        // то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
        Random rmd = new Random();

        boolean isYearFinished = rmd.nextBoolean();
        boolean isGoodWeather = rmd.nextBoolean();
        boolean hasBoughtRaincoats = rmd.nextBoolean();
        boolean isJimFree = rmd.nextBoolean();
        boolean hasKateComeBack = rmd.nextBoolean();

        if (isYearFinished && isGoodWeather) {
            if (hasBoughtRaincoats || (isJimFree && !hasKateComeBack)) {
                System.out.println("Ребята пойдут в поход!");
            } else {
                System.out.println("Ребята не пойдут в поход из-за погоды.");
            }
        } else {
            System.out.println("Ребята не пойдут в поход из-за окончания учебного года.");
        }


    }
}