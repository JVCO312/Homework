package game;

public enum Elements {
    STONE,
    SCISSORS,
    PARER
}
