import game.Elements;

import java.lang.annotation.ElementType;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Задание 2. Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит свой выбор
        // (в виде строки или числа). Программа случайным образом делает свой выбор и выводит на экран.
        // Далее программа показывает, кто победитель – пользователь или программа.
        Scanner scr = new Scanner(System.in);
        Random rnd = new Random();
        System.out.println("Давай поиграем в «Камень, ножницы, бумага!»");
        System.out.println("Введи свой ход: 1-Камень, 2-Ножницы, 3-Бумага");

        Elements[] elements = Elements.values();
        int userChoice = scr.nextInt();
        Elements user = elements [userChoice - 1];
        Elements pc = elements[rnd.nextInt(3)];

        System.out.println("Ваш выбор " + user);
        System.out.println("Выбор компьютера " + pc);

        if (user == pc) {

            System.out.println("Ничья!");
        } else if ((user == Elements.PARER && pc == Elements.STONE) ||
                (user == Elements.SCISSORS && pc == Elements.PARER) ||
                (user == Elements.STONE && pc == Elements.SCISSORS)) {
            System.out.println("Вы победили!");
        } else {
            System.out.println("Компьютер победил!");
        }


    }
}