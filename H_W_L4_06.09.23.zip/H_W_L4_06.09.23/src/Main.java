import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
        // Остаток деления можно отбросить. Операторы деления / и остатка от деления % применять нельзя.
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите целое число: ");
        int user = scn.nextInt();
        int result = (user >> 1);
        System.out.println("результат деление на два равен: " + result);
    }
}