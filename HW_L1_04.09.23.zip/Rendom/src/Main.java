import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rn = new Random();
        int i = rn.nextInt();
        long l = rn.nextLong();
        float f = rn.nextFloat();
        double d = rn.nextDouble();
        boolean b1 = rn.nextBoolean();
        short sh = (short) rn.nextInt();
        String string = ""+(char)rn.nextInt();
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(b1);
        System.out.println(sh);
        System.out.println(string);
        //я не смог вывезти byte(

        String s1 = String.valueOf(rn.nextInt());
        System.out.println(s1);



    }
}