import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
     //Задание 2
        //Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес. Когда все данные
        // введены, программа должна выдать сообщение: «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как
        // [Вес] килограмм золота.». В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите своё имя");
        String name = sc.nextLine();
        System.out.println("сколько вам лет?");
        String age = sc.nextLine();
        System.out.println("какой у вас вес?");
        String weigh = sc.nextLine();
        System.out.println("Уважаемый, "+name+"!"+ "В свои " +age+ " лет Вы для нас дороги, как "+weigh+ " килограмм золота");




    }
}