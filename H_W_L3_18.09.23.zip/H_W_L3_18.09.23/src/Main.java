import week.DayOfWeek;

import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Задание 3
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        // Программа должна вывести все дни недели, кроме данного
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите день недели: ");
        String day = scn.nextLine();

        System.out.println("Все остальные дни:");

        for (DayOfWeek d : DayOfWeek.values()) {
            if (day.equalsIgnoreCase(d.name())) {
                continue;
            }
            System.out.println(d);
        }
    }
}