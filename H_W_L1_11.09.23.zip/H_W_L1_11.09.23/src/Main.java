import java.util.Random;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: №1
        //Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //
        //Например:
        //ввод: m=10.5, n=10.45
        //вывод: Число 10.45 ближе к 10.
        Random rmd = new Random();
        float m = rmd.nextFloat(-15,15);
        float n = rmd.nextFloat(-15,15);

        System.out.println("m = " + m);
        System.out.println("n = " + n);

        float m1 =(Math.abs(m-10));
        float n1 =(Math.abs(n-10));

        System.out.println(m1);
        System.out.println(n1);

        if (m1<n1) {
            System.out.println("Число " + m + " ближе к 10.");
        }else {
            System.out.println("Число " + n + " ближе к 10.");
        }

    }
}