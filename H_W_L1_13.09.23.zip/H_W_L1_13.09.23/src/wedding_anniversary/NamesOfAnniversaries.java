package wedding_anniversary;

public enum NamesOfAnniversaries {
    CALICO_WEDDING,
    PAPER_WEDDING,
    LEATHER_WEDDING,
    LINEN_WEDDING,
    WOODEN_WEDDING,
    CAST_IRON_WEDDING,
    COPPER_WEDDING,
    TIN_WEEDING,
    EARTHENWARE_WEDDING,

}
