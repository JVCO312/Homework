import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //№2
        //Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения. Пользователь
        // сам вводит два целых однозначных числа. Программа задаёт вопрос: результат умножения первого
        // числа на второе.  Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
        Scanner cs = new Scanner(System.in);
        System.out.println("Введите целое число:");
        int num1 = cs.nextInt();
        System.out.println("Введите второе целое число:");
        int num2 = cs.nextInt();
        int res1 = (num1 * num2);
        System.out.println("Введите результат умножения первого числа на второе.");
        int answer = cs.nextInt();
        if (res1 == answer) {
            System.out.println("Поздравляем вы ответили правильно!");
        } else {
            System.out.println("Вы ошиблись! Правильный ответ: " + res1);
        }

    }
}