import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение),
        // разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел. Результат вычислений
        // выведите в консоль.
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите любое число");
        int step1 = sc.nextInt();
        System.out.println("Введите еще одно число");
        int step2 = sc.nextInt();
        System.out.println("сложение = " + (step1+step2));
        System.out.println("вычитание = " + (step1-step2));
        System.out.println("умножение = " + (step1*step2));
        System.out.println("деление = " + (step1/step2));
       // System.out.println("разницa= "(step1-step2));
        //        System.out.println("произведение= "(step1*step2);
        //        System.out.println("частное= "(step1/step2));





    }
}