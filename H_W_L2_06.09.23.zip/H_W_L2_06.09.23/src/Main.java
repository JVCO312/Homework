import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        // Выведите сумму сдачи в виде “X рублей и Y копеек”.
        Scanner scn = new Scanner(System.in);

        System.out.println("Введите суммарную стоимость покупок рубли и копейки разделяя их через точку:");
        double summaPokupok = scn.nextDouble();

        System.out.println("Введите сумму денег рубли и копейки разделяя их через точку:");
        double summaDeneg = scn.nextDouble();

        double chance = (summaDeneg - summaPokupok);

        int rubles = (int) chance;
        int kopecks = (int)((chance-rubles)*100);

        System.out.println("сдача:");
        System.out.println((rubles)+" рублей");
        System.out.println((kopecks)+" копеек");


    }
}