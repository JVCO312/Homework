import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        System.out.println("Введите длину в метрах: ");
        double meters = scn.nextDouble();

        double kilometers = meters / 1000.0;
        double miles = meters * 0.000621371;
        double feet = meters * 3.28084;
        double yards = meters * 1.09361;

        System.out.println("Длина в метрах: " + meters);
        System.out.println("Длина в километрах: " + kilometers);
        System.out.println("Длина в милях: " + miles);
        System.out.println("Длина в футах: " + feet);
        System.out.println("Длина в аршинах: " + yards);
    }
}