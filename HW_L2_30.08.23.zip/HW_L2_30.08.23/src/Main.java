public class Main {
    public static void main(String[] args) {
       int chislo = 312;
        System.out.println("Число"+" "+chislo+" "+"->"+" "+chislo/100+","+chislo%100/10+","+chislo%10);
    }
}