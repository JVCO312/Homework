import javax.print.MultiDocPrintService;
import javax.swing.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Задание 2
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.

        //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
        // Программу повторять, пока пользователь не введёт «quit».

        Scanner scanner = new Scanner(System.in);

        String userInput;

            System.out.println("Введите начало диапазона: ");
            int start = scanner.nextInt();

            System.out.println("Введите конец диапазона: ");
            int end = scanner.nextInt();scanner.nextLine();

            int min = Math.min(start, end);
            int max = Math.max(start, end);

            int sum = 0;
            String str = "";

            do {
                for (int i = min; i <= max; i++) {
                    if (i % 2 != 0) {
                        sum += i;
                    }

                }
                System.out.println(sum);
                System.out.println("Введите \"quit\" для выхода");
                str = scanner.nextLine();
            }while (!"quit".equalsIgnoreCase(str));


//            for (int i = min; i <= max ; i++) {
//                sum+=i;
//            }
//
//            System.out.println("Сумма нечетных чисел в диапазоне от " + start + " до " + end + ": " + sum);
//
//            System.out.print("Для выхода введите 'quit', для продолжения нажмите Enter: ");
//        }
//        while(!"quit".equalsIgnoreCase(scanner.nextLine()));
//
//        System.out.println("Программа завершена.");
    }


}