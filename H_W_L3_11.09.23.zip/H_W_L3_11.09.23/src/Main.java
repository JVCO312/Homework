import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //№3
        //Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите программу, в которой
        // пользователь вводит год. Если указанный год меньше 1935, то вывести «Элвис ещё не родился». Если указанный
        // пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!». Если введённый пользователем год
        // больше 1977, то вывести «Элвис навсегда в наших сердцах!»
        Scanner cs = new Scanner(System.in);
        System.out.println("Пожалуйста введите год:");
        int answer = cs.nextInt();

        String massage= (answer < 1935) ? "Элвис ещё не родился" :
                (answer >= 1935 && answer <= 1977) ? "Элвис жив!" :
                        (answer > 1977) ? "Элвис навсегда в наших сердцах!":"";

        System.out.println(massage);

    }

}
//        if (answer < 1935) {
//            System.out.println("Элвис ещё не родился");
//
//        }
//        if (answer >= 1935 && answer <= +1977) {
//            System.out.println("Элвис жив!");
//
//        }
//        if (answer>1977){
//            System.out.println("Элвис навсегда в наших сердцах!");
//
//        }