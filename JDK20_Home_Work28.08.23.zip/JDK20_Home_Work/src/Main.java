public class Main {
    public static void main(String[] args) {
        System.out.println("Hello,");
        System.out.println("my");
        System.out.println("name");
        System.out.println("is");
        System.out.println("Zhyrgalbek Abdyldaev");
        System.out.printf("Hello, my name is Zhyrgalbek Abdyldaev");
    }
}